// ==UserScript==
// @name     nonograms-katana
// @include  https://nonograms-katana.com/play/*
// @version  1-2020
// @grant    GM.getValue
// @grant    GM.setValue
// @grant 	 GM.deleteValue
// @grant 	 GM.openInTab
// @grant 	 GM.setClipboard
// @require  http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js
// ==/UserScript==

// ---------------------------------------------
// -- Initialisation
// ---------------------------------------------
let $ = window.jQuery;

console.log("start nonograms-katana");

let body = $("body");
let embedDa = $("#embed-da");

console.log(embedDa);

body.css("background-color","rgb(34, 34, 34)");
embedDa.css("background-color","rgb(34, 34, 34)");
embedDa.text("");
